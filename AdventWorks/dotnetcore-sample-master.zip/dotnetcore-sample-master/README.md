# Sample ASP.NET Core application for VSTS and TFS docs

For information on how to use this repository, see [Build your ASP.NET Core app](https://docs.microsoft.com/en-us/vsts/build-release/apps/aspnet/build-aspnet-core).
